

s = serialport("COM6",115200,"Timeout",90);

t_data = read(s, 100, "uint8");
receive_data = zeros(10, 10);
idx = 1;
for a = 1 : 10
     for b = 1 : 10
         receive_data(a, b) = t_data(idx);
         idx = idx + 1;
     end
end

tmp = receive_data;
prob_matrix = zeros(10, 10);
for x = 1 : 10
    row_data = tmp(x, :);
    exp_row_data = exp(row_data);
    sum_exp_row_data = sum(exp_row_data);
    for y = 1 : 10
        data = tmp(x, y);
        exp_data = exp(data);
        prob_matrix(x, y) = exp_data/sum_exp_row_data;
    end
end

disp(prob_matrix);

predict = zeros(1, 10);
for row = 1 : 10
    max_value = max(prob_matrix(row, :));
    max_index = find(prob_matrix(row, :) == max(prob_matrix(row, :)));
    if length(max_index) > 1
        max_index = max_index(1);
    end
    predict(row) = max_index;
end
disp(predict)

img0 = imread('example_img/545_label_0.bmp');
img1 = imread('example_img/537_label_1.bmp');
img2 = imread('example_img/547_label_2.bmp');
img3 = imread('example_img/548_label_3.bmp');
img4 = imread('example_img/555_label_4.bmp');
img5 = imread('example_img/570_label_5.bmp');
img6 = imread('example_img/566_label_6.bmp');
img7 = imread('example_img/557_label_7.bmp');
img8 = imread('example_img/563_label_8.bmp');
img9 = imread('example_img/558_label_9.bmp');

f = figure;
f.Position(1:4) = [50 150 1800 720];

empty = ones(28, 28);
subplot(1, 11, 1), imshow(empty);
annotation('textbox',[.127 .44 .1 .1], ...
'String','input image','EdgeColor','none', fontsize=15)
title('predict label', fontsize=15) 
subplot(1, 11, 2), imshow(img0)
title(predict(1)-1, fontsize=20)
subplot(1, 11, 3), imshow(img1)
title(predict(2)-1, fontsize=20)
subplot(1, 11, 4), imshow(img2)
title(predict(3)-1, fontsize=20)
subplot(1, 11, 5), imshow(img3)
title(predict(4)-1, fontsize=20)
subplot(1, 11, 6), imshow(img4)
title(predict(5)-1, fontsize=20)
subplot(1, 11, 7), imshow(img5)
title(predict(6)-1, fontsize=20)
subplot(1, 11, 8), imshow(img6)
title(predict(7)-1, fontsize=20)
subplot(1, 11, 9), imshow(img7)
title(predict(8)-1, fontsize=20)
subplot(1, 11, 10), imshow(img8)
title(predict(9)-1, fontsize=20)
subplot(1, 11, 11), imshow(img9)
title(predict(10)-1, fontsize=20)

sgtitle('2023 DSD Term Project (MLP)', 'fontsize', 30);
